import React from 'react'

const CP_Payments = () => {
  return (
    <div>CP_Payments</div>
  )
}

export default CP_Payments